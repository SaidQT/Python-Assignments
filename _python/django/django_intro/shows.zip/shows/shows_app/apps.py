from django.apps import AppConfig


class ShowsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shows_app'
