from django.shortcuts import render
from . models import Dojo,Ninja
def index(request):
    data={
        "dojos": Dojo.objects.all(),
        "ninjas":Ninja.objects.values().filter(dojo_id=4),
    }
    
    return render(request, "index.html",data)