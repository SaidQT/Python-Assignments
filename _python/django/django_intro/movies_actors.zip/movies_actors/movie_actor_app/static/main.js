var x= document.querySelector(".card")
