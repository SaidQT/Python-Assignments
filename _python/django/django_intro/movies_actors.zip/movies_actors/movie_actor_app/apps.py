from django.apps import AppConfig


class MovieActorAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'movie_actor_app'
